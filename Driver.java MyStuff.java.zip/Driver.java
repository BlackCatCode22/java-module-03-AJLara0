package mystuff;

public class Driver {
    String brand;
    String color;
    String type;
    double size;
    boolean shoeLaces;

}
