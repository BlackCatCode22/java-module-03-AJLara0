package mystuff;

public class MyStuff {
    public static void main(String [] args){

        Driver myDriver = new Driver();
        myDriver.brand = "Timberland";
        myDriver.color = "Black";
        myDriver.type = "Boots";
        myDriver.size = 12;
        myDriver.shoeLaces = true;

        Driver myDriver2 = new Driver();
        myDriver2.brand = "Adidas";
        myDriver2.color = "Blue";
        myDriver2.type = "Sandals";
        myDriver2.size = 11.5;
        myDriver2.shoeLaces = false;

    }
}
