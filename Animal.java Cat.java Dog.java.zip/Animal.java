package myanimals;

public class Animal {
    public static void main(String[] args){
        System.out.println(Cat.getCatCount());


        Cat myCat = new Cat();
        myCat.meow();
        myCat.name = "Stella";
        myCat.age = 8;
        System.out.println(Cat.MAX_LIVES);

        Dog myDog = new Dog();
        myDog.name = "Don";
        myDog.age =28;

        Dog myDog2 = new Dog();
        myDog2.name = "Ron";
        myDog2.age =28;

        System.out.println(Cat.getCatCount());
        System.out.println(Dog.getDogCount()+Cat.getCatCount());
    }
}
